package com.sundaysmp.hammer;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.Container;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.inventory.view.AnvilView;

import java.util.*;

public class SundayHammer extends JavaPlugin implements Listener {

    private NamespacedKey key;
    private final Set<UUID> working = new HashSet<>();
    private final Set<Material> blacklist = EnumSet.noneOf(Material.class);

    @Override
    public void onEnable() {
        saveDefaultConfig();
        key = new NamespacedKey(this, "hammer3x3");
        loadBlacklist();
        getServer().getPluginManager().registerEvents(this, this);
    }

    private void loadBlacklist() {
        blacklist.clear();
        for (String s : getConfig().getStringList("blacklist")) {
            Material m = Material.matchMaterial(s);
            if (m != null) blacklist.add(m);
        }
    }

    private Component text(String legacy) {
        return LegacyComponentSerializer.legacySection().deserialize(legacy)
                .decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack createBook() {
        ItemStack book = new ItemStack(Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        meta.displayName(text(getConfig().getString("book-name", "§bEnchanted Book 3x3")));
        List<Component> lore = new ArrayList<>();
        for (String l : getConfig().getStringList("book-lore")) lore.add(text(l));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        book.setItemMeta(meta);
        return book;
    }

    private boolean has(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer().has(key, PersistentDataType.BYTE);
    }

    private boolean isPickaxe(ItemStack item) {
        return item != null && item.getType().name().endsWith("_PICKAXE");
    }

    // ---------- Anvil: book + pickaxe ----------
    @EventHandler
    public void onAnvil(PrepareAnvilEvent e) {
        ItemStack a = e.getInventory().getFirstItem();
        ItemStack b = e.getInventory().getSecondItem();
        if (!isPickaxe(a) || b == null || b.getType() != Material.ENCHANTED_BOOK || !has(b)) return;
        if (has(a)) { e.setResult(null); return; } // มี 3x3 อยู่แล้ว

        ItemStack result = a.clone();
        ItemMeta meta = result.getItemMeta();
        meta.getPersistentDataContainer().set(key, PersistentDataType.BYTE, (byte) 1);
        List<Component> lore = meta.hasLore() && meta.lore() != null
                ? new ArrayList<>(meta.lore()) : new ArrayList<>();
        lore.add(text(getConfig().getString("tool-lore", "§d3x3")));
        meta.lore(lore);
        meta.setEnchantmentGlintOverride(true);
        result.setItemMeta(meta);
        e.setResult(result);
        if (e.getView() instanceof AnvilView view) {
            view.setRepairCost(getConfig().getInt("anvil-cost", 5));
        }
    }

    // ---------- Mining 3x3 ----------
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (working.contains(p.getUniqueId())) return;
        if (p.getGameMode() != GameMode.SURVIVAL) return;
        ItemStack tool = p.getInventory().getItemInMainHand();
        if (!isPickaxe(tool) || !has(tool)) return;
        if (!p.hasPermission("sundayhammer.use")) return;
        if (p.isSneaking() && getConfig().getBoolean("sneak-disables", true)) return;

        Block center = e.getBlock();
        BlockFace face = null;
        RayTraceResult r = p.rayTraceBlocks(7);
        if (r != null && r.getHitBlock() != null && r.getHitBlock().equals(center)) {
            face = r.getHitBlockFace();
        }
        if (face == null) face = p.getFacing().getOppositeFace();

        boolean onlyPick = getConfig().getBoolean("only-pickaxe-blocks", true);
        working.add(p.getUniqueId());
        try {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    if (i == 0 && j == 0) continue;
                    Block b;
                    switch (face) {
                        case UP, DOWN -> b = center.getRelative(i, 0, j);
                        case NORTH, SOUTH -> b = center.getRelative(i, j, 0);
                        default -> b = center.getRelative(0, j, i);
                    }
                    ItemStack cur = p.getInventory().getItemInMainHand();
                    if (!isPickaxe(cur) || !has(cur)) return; // พิกเอ็กซ์พังแล้ว
                    Material t = b.getType();
                    if (t.isAir() || b.isLiquid() || blacklist.contains(t)) continue;
                    if (t.getHardness() < 0) continue;
                    if (b.getState() instanceof Container) continue;
                    if (onlyPick && !b.isPreferredTool(cur)) continue;
                    p.breakBlock(b);
                }
            }
        } finally {
            working.remove(p.getUniqueId());
        }
    }

    // ---------- Command ----------
    @Override
    public boolean onCommand(CommandSender s, Command c, String l, String[] a) {
        if (!s.hasPermission("sundayhammer.give")) {
            s.sendMessage(getConfig().getString("messages.no-permission", "no perm"));
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("reload")) {
            reloadConfig(); loadBlacklist();
            s.sendMessage("§aReloaded");
            return true;
        }
        if (a.length >= 1 && a[0].equalsIgnoreCase("give")) {
            Player target = null;
            if (a.length >= 2) target = getServer().getPlayerExact(a[1]);
            else if (s instanceof Player pl) target = pl;
            if (target == null) {
                s.sendMessage(getConfig().getString("messages.player-not-found", "not found"));
                return true;
            }
            target.getInventory().addItem(createBook()).values()
                    .forEach(i -> target.getWorld().dropItemNaturally(target.getLocation(), i));
            s.sendMessage(getConfig().getString("messages.given", "given"));
            return true;
        }
        s.sendMessage(getConfig().getString("messages.usage", "/hammer give [player]"));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("give", "reload");
        return null;
    }
}
